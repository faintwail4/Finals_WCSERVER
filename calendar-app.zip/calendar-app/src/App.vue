<template>
  <main id="app-container">
    <header class="app-header">
      <h1>7-Day Interactive Weekly Calendar</h1>
    </header>

    <CalendarWeek />
    <CalendarEntry />
  </main>
</template>

<script>
import CalendarWeek from './components/CalendarWeek.vue';
import CalendarEntry from './components/CalendarEntry.vue';

export default {
  name: 'App',
  components: {
    CalendarWeek,
    CalendarEntry
  }
};
</script>

<style>
#app-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 24px;
  font-family: Arial, Helvetica, sans-serif;
}
.app-header {
  text-align: center;
  margin-bottom: 32px;
  color: #2c3e50;
}
</style>